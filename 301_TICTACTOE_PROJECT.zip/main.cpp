#include <aio.h>
#include <array>
#include <cstdio>
#include <iostream>
#include <stdio.h>
#include <string>
#include <sstream>
#include <memory>
#include <cstdlib>

using namespace std;

// Function declerations
void dispIntro();
void dispRules();
string yesNoVerify();

//FUNCTION DEFINITIONS

// Function that converts the string element into an integer for //game board display
int moveToGrid(string move){
restart:

  if(move == "1" || move == "2" || move == "3" || move == "4" || move == "5" || move == "6" || move == "7" || move == "8" || move == "9"){
  stringstream grid(move);
  int gridP;
  grid >> gridP;
  return gridP;
  }else{
    cout << "Please enter a number 1-9: ";
    cin >> move;
    goto restart;
  }
}

//Asks for the player's names
string getName(int nameCount){
  string name;
  cout << "Please enter the name of Player #";
  cout << nameCount+1 << ": ";
  cin >> name;
  return name;
}

// Input validation function that verifies whether a space is //occupied by another piece.
bool checkTile(string gameArray[], int tile) {
	bool valid;
	if (gameArray[tile - 1] == "X" || gameArray[tile - 1] == "O") {
		valid = false;
	} else
		valid = true;
	return valid;
}

/*Each player will select a tile number according to the game board. Player 1's tile choice is replaced with an 'X', and Player 2's tile choice is replaced with the letter 'O'.*/
void playerInput (string square[], int tile, string playerPiece) {
  square[tile - 1] = playerPiece;
}

// Displaying initial game board
void displayBoard (string gameArray[])
{
  cout << endl;
  cout << " " << gameArray[0] << " | " << gameArray[1] << " | " << gameArray[2] << endl;
  cout << "___|___|___" << endl;
  cout << " " << gameArray[3] << " | " << gameArray[4] << " | " << gameArray[5] << endl;
  cout << "___|___|___" << endl;
  cout << " " << gameArray[6] << " | " << gameArray[7] << " | " << gameArray[8] << endl << endl;
}

/*From the desired tile, the tiles around it will be compared for similar pieces. The combinations are numbered according to the tile identifications and adjusted for the subscripts. Since the tile location has already been proven empty, this function does not need to worry about re-assigning a space with the entry.*/
string findWinner(string gameArray[], int tile, string gamePiece) {
	string winner;
	// The desired tile
	switch (tile - 1) {
	case 0:
		// The first row for comparison
		if (gameArray[1] == gamePiece && gameArray[2] == gamePiece) {
			winner = gamePiece;
		}
		// The next row for comparison
		else if (gameArray[3] == gamePiece && gameArray[6] == gamePiece) {
			winner = gamePiece;
		} 
    else if (gameArray[4] == gamePiece && gameArray[8] == gamePiece) {
			winner = gamePiece;
		}
    else {
			winner = "none";
		}
		break;
	case 1:
		if (gameArray[0] == gamePiece && gameArray[2] == gamePiece) {
			winner = gamePiece;
		} 
    else if (gameArray[4] == gamePiece && gameArray[7] == gamePiece) {
			winner = gamePiece;
		} 
    else {
			winner = "none";
		}
		// Certain tiles have two rows to compare
		break;
	case 2:
		if (gameArray[0] == gamePiece && gameArray[1] == gamePiece) {
			winner = gamePiece;
		} 
    else if (gameArray[4] == gamePiece && gameArray[6] == gamePiece) {
			winner = gamePiece;
		}
    else if (gameArray[5] == gamePiece && gameArray[8] == gamePiece) {
			winner = gamePiece;
		}
    else {
			winner = "none";
		}
		break;
	case 3:
		if (gameArray[0] == gamePiece && gameArray[6] == gamePiece) {
			winner = gamePiece;
		}
    else if (gameArray[4] == gamePiece && gameArray[5] == gamePiece) {
			winner = gamePiece;
		}
    else {
			winner = "none";
		}
		break;
	case 4:
		if (gameArray[0] == gamePiece && gameArray[8] == gamePiece) {
			winner = gamePiece;
		}
    else if (gameArray[1] == gamePiece && gameArray[7] == gamePiece) {
			winner = gamePiece;
		}
    else if (gameArray[2] == gamePiece && gameArray[6] == gamePiece) {
			winner = gamePiece;
		}
    else if (gameArray[3] == gamePiece && gameArray[5] == gamePiece) {
			winner = gamePiece;
		}
    else {
			winner = "none";
		}
		break;
	case 5:
		if (gameArray[2] == gamePiece && gameArray[8] == gamePiece) {
			winner = gamePiece;
		}
    else if (gameArray[3] == gamePiece && gameArray[4] == gamePiece) {
			winner = gamePiece;
		}
    else {
			winner = "none";
		}
		break;
	case 6:
		if (gameArray[0] == gamePiece && gameArray[3] == gamePiece) {
			winner = gamePiece;
		}
    else if (gameArray[2] == gamePiece && gameArray[4] == gamePiece) {
			winner = gamePiece;
		}
    else if (gameArray[7] == gamePiece && gameArray[8] == gamePiece) {
			winner = gamePiece;
		}
    else {
			winner = "none";
		}
		break;
	case 7:
		if (gameArray[1] == gamePiece && gameArray[4] == gamePiece) {
			winner = gamePiece;
		}
    else if (gameArray[6] == gamePiece && gameArray[8] == gamePiece) {
			winner = gamePiece;
		}
    else {
			winner = "none";
		}
		break;
	case 8:
		if (gameArray[0] == gamePiece && gameArray[4] == gamePiece) {
			winner = gamePiece;
		}
    else if (gameArray[2] == gamePiece && gameArray[5] == gamePiece) {
			winner = gamePiece;
		}
    else if (gameArray[6] == gamePiece && gameArray[7] == gamePiece) {
			winner = gamePiece;
		}
    else {
			winner = "none";
		}
		break;
		/*No default is necessary as the tile input has been checked to make sure it falls between 1 and 9, and the break commands push the program out of the function.*/
	}
	return winner;
}

//Determines when the game is a draw
string findDraw(int rounds, string &wnr){
  if (rounds>=9 && wnr!="O" && wnr!="X"){
    wnr = "draw";
  }
  return wnr;
}

string toLow(string ans){
  for(int i=0;i<ans.length();i++){
    ans[i] = tolower(ans[i]);
  }
  return ans;
}

void congratWin(string names[], string rndwnr){
  if (rndwnr == "X"){
    cout << names[0] << " is the winner!\n" << endl;
  }
  else if (rndwnr == "O"){
    cout << names[1] << " is the winner!\n" << endl;
  }
  else {
    cout << "You two are matched. This round is a draw!\n";
    cout << endl;
  }
}

//The score board will update each round
void scoreboardUpdate(string winPiece, int &p1, int &p2, int &draw){
  if (winPiece == "X"){
    p1 = p1+1;
  }
  else if (winPiece == "O"){
    p2 = p2+1;
  }
  else {
    draw = draw+1;
  }
}

void dispScrBrd(string nameArray[], int p1, int p2, int draw){
  cout << nameArray[0] << " scored ";
  if (p1==1){
	  cout << p1 << " point." << endl;
  }
  else {
    cout << p1 << " points." << endl;
  }
  cout << nameArray[1] << " scored ";
  if (p2==1){
    cout << p2 << " point." << endl;
  }
  else {
    cout << p2 << " points." << endl;
  }
  if (draw==1){
    cout << "There was " << draw;
    cout << " draw." << endl;
  }
  else {
    cout << "There were " << draw;
    cout << " draws." << endl;
  }
}
//--------------------------------------------------------------
//MAIN PROGRAM

int main() {
	// Global variables
	const int SIZE = 9;   //for the game progress array
	string player1Piece = "X", player2Piece = "O";
	string nameSet[2];						// player names
	string winner;						  	  // winning game piece
	string moveP1, moveP2;						// game board location
  int gridP1, gridP2;  //game board location, converted to integer
	string wantPlay;					  	// game interest request
  string changePiece;           // switch X/O
	int p1Score = 0, p2Score = 0; // points counter
	int tieScore = 0;				      // game draw counter
	int counter;						    	// the number of rounds
	bool tileEmpty = true;				// used for the input validation

	// Game Introduction
	dispIntro();

	// Instructions and Rules
	dispRules();

  // Loop to enter the players' names
  cout << endl;
  for (int i = 0; i < 2; i++) {
    nameSet[i] = getName(i);
  }

  // Major game loop; controls the entirety of one game
  do{
    winner = "none";         //intialize the winner flag
		counter = 0;          //initialize the round counter
    //initialize the game board for each round
    string gameArray[SIZE] = {"1","2","3","4","5","6","7","8","9"};
    displayBoard(gameArray);

		// Minor loop; controls the exchange of turns
		while (counter <= 9 && winner != "X" && winner != "O" && winner != "draw"){
      if (counter == 0){
        cout << "Please enter your move ";
      }
			cout << nameSet[0] << ": ";
			cin >> moveP1;
      gridP1 = moveToGrid(moveP1);
			
      // Checks the player has moved into an empty space
			tileEmpty = checkTile(gameArray, gridP1);

			// loop to re-enter the space if it's not empty
			while (tileEmpty == false) {
				cout << "Please enter an empty space: ";
				cin >> moveP1;
        gridP1 = moveToGrid(moveP1);
				tileEmpty = checkTile(gameArray, gridP1);
			}

			// Enter the game piece and display the entry on the board
			playerInput(gameArray, gridP1, player1Piece);
			displayBoard(gameArray);
      
			counter++; // add to the move counter

			// Check if there's a winner after 5 or more moves
			if (counter >= 5) {
				winner = findWinner(gameArray, gridP1, player1Piece);
        findDraw(counter, winner);
			}

			// Check if Player 2 is allowed to move
			if (counter < 9 && winner != "X") {
				cout << nameSet[1] << ": ";
				cin >> moveP2;
        gridP2 = moveToGrid(moveP2);
				tileEmpty = checkTile(gameArray, gridP2);

				while (tileEmpty == false) {
					cout << "Please enter an empty space: ";
					cin >> moveP2;
          gridP2 = moveToGrid(moveP2);
					tileEmpty = checkTile(gameArray, gridP2);
				}

				playerInput(gameArray, gridP2, player2Piece);
				displayBoard(gameArray);
				counter++;

				if (counter >= 5) {
					winner = findWinner(gameArray, gridP2, player2Piece);
          findDraw(counter, winner);
				}
			}
		}
    //Display the round's winner
    congratWin(nameSet, winner);

		// Add the points to the winner's score
		scoreboardUpdate(winner, p1Score, p2Score, tieScore);

		// Ask if they'd like another game
		cout << "Do you wish to play again?";
		cout << " (Please enter 'yes' or 'no'): ";
		wantPlay = yesNoVerify();
    cout << endl;

	} while (wantPlay == "yes");

	// Display the scoreboard
	dispScrBrd(nameSet, p1Score, p2Score, tieScore);
	cout << "\nThanks for playing Tic-Tac-Toe!";
	cout << " Have a great day!\n\n";

	return 0;
}

//---------------------------------------------------------------
// MODULE DEFINITIONS

void dispIntro(){
  cout << "\n                            TIC-TAC-TOE     \n\n";
	cout << "Welcome to Group 2's program! This game is";
	cout << " designed for two people, so if you haven't ";
	cout << "already, grab a buddy to play this game with you.";
	cout << " The program will soon ask for your names, ";
	cout << "so please decide on who wants to be Player 1";
	cout << " ('X') and who wants to be Player 2 ('O').";
	cout << endl << endl;
}

void dispRules(){
  cout << "Below, you will see a table consisting of 9";
	cout << " numbers: 1-3 in the top row, 4-6 in the middle";
	cout << " row, and 7-9 in the bottom row. The two of you";
	cout << " will take turns placing marks ('X'/'O') on the ";
	cout << "board. To do this, enter the number";
  cout << " that corresponds";
	cout << " to the position you wish to reserve. The first";
	cout << " person to place three marks in a row, in any";
	cout << " direction is the winner!" << endl;
  cout << "...................................";
}

string yesNoVerify() {
restartQ:
	string restart;
	cin >> restart;
	for (int i = 0; i < restart.length(); i++) {
		restart[i] = toupper(restart[i]);
	}
	if (restart == "YES" || restart == "Y") {
		return ("yes");
	} 
  else if (restart == "NO" || restart == "N") {
		return ("no");
	} 
  else {
		cout << "That was not a valid response, please provide yes or no only: ";
		goto restartQ;
	}
}